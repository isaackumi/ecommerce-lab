<?php
ob_start();
session_start();
require ('../controllers/productcontroller.php');


if (isset($_POST['add_brand'])){

    $brand_name = $_POST['brand_name'];
    $add = addBrand($brand_name);
    if ($add){

        $_SESSION['brand_success'] = 'Successfully added to brand';
        header('Location: ../admin/index.php');

    }else{
        $_SESSION['brand_error'] = 'Error adding to brand';
        header('Location: ../admin/index.php');
    }
}



if (isset($_POST['add_category'])) {

    $cat_name = $_POST['cat_name'];
    echo $cat_name;
    $add = addCategory($cat_name);
    if ($add){

        $_SESSION['cat_success'] = 'Successfully added to category';
        header('Location: ../admin/index.php');

    }else{
        $_SESSION['cat_error'] = 'Error adding to category';
        header('Location: ../admin/index.php');
    }
}